#!/bin/bash

kubectl delete ns unfit

tag=noagent

while getopts ":a:e:t:" opt; do
  case $opt in
    
    a)
      tag=$OPTARG
      ;;
    e)
      manager_url=$OPTARG
      ;;
    t)
      manager_token=$OPTARG
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;

    :)
      echo "Option -$OPTARG requires an argument." >&2
      exit 1
      ;;

  esac
done

if [ -n "$manager_url" ]; then
   sub_emhost="-e s|MANAGER_URL_VALUE|$manager_url|"
fi

sub_emport="-e s|MANAGER_TOKEN_VALUE|$manager_token|"
sub_tag="-e s|IMAGE_TAG|$tag|"

echo "sed $sub_tag $sub_emhost $sub_emport sample.dataengine.yaml > dataengine.yaml"
echo Waiting for 60 sec for complete cleanup of unfit namespace object
sed $sub_tag $sub_emhost $sub_emport sample.dataengine.yaml > dataengine.yaml

sleep 60
findExternalIP()
{
   externalIP=`kubectl get svc $1 -n unfit -o yaml | grep hostname | tail -1 | cut -f2 -d ":"`
   echo $externalIP
}
kubectl create ns unfit
kubectl create -f dataengine.yaml -n unfit
kubectl get pods -n unfit --watch
kubectl get svc -n unfit
dataengineserviceip=$(findExternalIP dataengine)
echo $dataengineserviceip
sed $sub_tag $sub_emhost $sub_emport -e "s/DATAENGINE_EXTERNAL_IP/$dataengineserviceip/" sample.unfit.yaml > unfit.yaml
kubectl create -f unfit.yaml -n unfit
kubectl get pods -n unfit --watch
kubectl get svc -n unfit
activityserviceip=$(findExternalIP activityservice)
foodserviceip=$(findExternalIP foodservice)
tokenserviceip=$(findExternalIP tokenservice)
userserviceip=$(findExternalIP userservice)

echo $activityserviceip $dataengineserviceip $foodserviceip $tokenserviceip $userserviceip

sed -e "s/activity_ip/$activityserviceip/" -e "s/token_ip/$tokenserviceip/" -e "s/user_ip/$userserviceip/" -e "s/food_ip/$foodserviceip/" sample.config.json > config.json

docker build -t webapp .
docker rm -f webapp
docker run -d -p 8000:80 --name webapp webapp

rm config.json unfit.yaml dataengine.yaml
