# Unfit Application on Kubernetes

This contains the instruction of installing or configuring [unfit](https://github-isl-01.ca.com/APMSWAT/unfit-demo-app) application on Kubernetes Cluster or Standalone setup. 

### Prerequisite
  - Kubernetes Cluster or standalone setup ( both on prem or google/aws cloud ) with proper LoadBalancer setup so that external IPs can be exposed. Try this [Test App](https://kubernetes.io/docs/tutorials/stateless-application/expose-external-ip-address/) to make sure the setup is exposing external IPs. 
  - Agent used for this application is from 10.7.0_dev branch on Nov 23, 2017

### Usage 
1. clone the repo 
```sh
$ git clone https://github-isl-01.ca.com/bhaab01/unfit-kubernetes.git
```
2. To run unfit app only
```sh
$ ./deployUnfitApp.sh
```
3. To run upfit app **with agent**
```sh
$ ./deployUnfitApp.sh -a agent -e [MANAGER_URL] -t [MANAGER_TOKEN]
```

Pass empty string "" as *MANAGER_TOKEN* if you want to connect to on-prem EM 

### Validation
* Run the following commands to make sure all Pods and Services are running 
```
$ kubectl get pods -n unfit
NAME                               READY     STATUS    RESTARTS   AGE
activityservice-1778550217-2rz93   1/1       Running   0          35m
dataengine-1553529458-2fgfv        1/1       Running   0          36m
foodservice-3466228931-r7qh6       2/2       Running   0          35m
tokenservice-3897966950-22s5w      1/1       Running   0          35m
userservice-536348443-1hjnr        1/1       Running   0          35m
$ kubectl get svc -n unfit
NAME              CLUSTER-IP      EXTERNAL-IP        PORT(S)                       AGE
activityservice   10.43.232.244   10.131.73.14       7030/TCP                      35m
dataengine        10.43.252.191   10.131.73.61,...   8080/TCP,1527/TCP,61616/TCP   36m
foodservice       10.43.81.89     10.131.73.61,...   7040/TCP,27017/TCP            35m
tokenservice      10.43.242.140   10.131.73.61       7010/TCP                      35m
userservice       10.43.214.217   10.131.115.18      7020/TCP                      35m

```

* Wait for 5 minutes before running the load or accessing the application

### Url of the the application ###

```http://<hostname>:8000```

### Uninstallation ###

Delete the unfit namespace
```
$kubectl delete ns unfit
```

### Known Issue
* foodservice ( NodeJS ) component is broken.  
